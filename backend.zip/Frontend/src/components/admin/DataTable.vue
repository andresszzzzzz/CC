<script setup>
import { ref, computed } from 'vue'
import AppIcon from '@/components/AppIcon.vue'

const props = defineProps({
  columns: { type: Array, required: true }, // [{ key, label, format?(valor, fila) }]
  rows: { type: Array, default: () => [] },
  cargando: { type: Boolean, default: false },
  error: { type: String, default: '' },
  soloLectura: { type: Boolean, default: false },
  // true = la tabla maneja activo/inactivo: primero se desactiva y solo entonces se puede activar o eliminar
  modoEstado: { type: Boolean, default: false }
})
defineEmits(['crear', 'editar', 'eliminar', 'desactivar', 'activar'])

const busqueda = ref('')

// Color del badge de la columna "estado". Lo no listado (p. ej. inactivo) queda en gris.
const TONO_ESTADO = {
  activo: 'ok', aprobada: 'ok', matriculada: 'ok', enviado: 'ok',
  pendiente: 'warn', borrador: 'warn',
  rechazada: 'bad'
}
const tonoEstado = (estado) => TONO_ESTADO[estado] || 'off'

// Lee claves anidadas como "credenciales.usuario".
const leer = (obj, ruta) => ruta.split('.').reduce((acc, k) => (acc == null ? acc : acc[k]), obj)

function textoCelda(fila, col) {
  const v = leer(fila, col.key)
  // col.format(valor, fila) -> texto. Para fechas, nombres compuestos, etc.
  if (col.format) {
    const f = col.format(v, fila)
    return f === null || f === undefined || f === '' ? '—' : String(f)
  }
  if (v === null || v === undefined || v === '') return '—'
  if (Array.isArray(v)) return String(v.length)
  if (typeof v === 'object') return v.nombre || v.nombreCompleto || '—'
  return String(v)
}

const filas = computed(() => {
  const q = busqueda.value.trim().toLowerCase()
  if (!q) return props.rows
  return props.rows.filter((fila) =>
    props.columns.some((col) => textoCelda(fila, col).toLowerCase().includes(q))
  )
})
</script>

<template>
  <div class="tabla-card">
    <div class="tabla-barra">
      <input v-model="busqueda" type="search" class="tabla-buscar" placeholder="Buscar…" />
      <button v-if="!soloLectura" class="btn-nuevo" @click="$emit('crear')">+ Nuevo</button>
    </div>

    <div v-if="cargando" class="tabla-estado">Cargando…</div>
    <div v-else-if="error" class="tabla-estado tabla-error">{{ error }}</div>
    <div v-else-if="!filas.length" class="tabla-estado">
      {{ rows.length ? 'Ninguna coincidencia con la búsqueda.' : 'Todavía no hay registros.' }}
    </div>

    <div v-else class="tabla-scroll">
      <table class="tabla">
        <thead>
          <tr>
            <th v-for="col in columns" :key="col.key">{{ col.label }}</th>
            <th v-if="!soloLectura" class="col-acciones">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="fila in filas" :key="fila._id" :class="{ 'fila-inactiva': modoEstado && fila.estado === 'inactivo' }">
            <td v-for="col in columns" :key="col.key">
              <span
                v-if="col.key === 'estado' && fila.estado"
                :class="['badge', 'badge-' + tonoEstado(fila.estado)]"
              >
                {{ fila.estado }}
              </span>
              <template v-else>{{ textoCelda(fila, col) }}</template>
            </td>
            <td v-if="!soloLectura" class="col-acciones">
              <button class="icono-btn" title="Editar" @click="$emit('editar', fila)">
                <AppIcon name="edit-3" :size="16" />
              </button>
              <!-- Tabla sin activo/inactivo: la papelera elimina como antes -->
              <template v-if="!modoEstado">
                <button class="icono-btn peligro" title="Eliminar" @click="$emit('eliminar', fila)">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
                </button>
              </template>
              <!-- Registro activo: la papelera DESACTIVA -->
              <template v-else-if="fila.estado !== 'inactivo'">
                <button class="icono-btn peligro" title="Desactivar" @click="$emit('desactivar', fila)">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
                </button>
              </template>
              <!-- Registro inactivo: ahora sí se puede activar de nuevo o eliminar -->
              <template v-else>
                <button class="txt-btn ok" title="Volver a activar" @click="$emit('activar', fila)">Activar</button>
                <button class="txt-btn bad" title="Eliminar definitivamente" @click="$emit('eliminar', fila)">Eliminar</button>
              </template>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<style scoped>
.tabla-card { background: white; border-radius: 16px; border: 1px solid #f1f5f9; box-shadow: 0 4px 16px rgba(0,0,0,0.03); padding: 16px; }
.tabla-barra { display: flex; gap: 12px; justify-content: space-between; margin-bottom: 14px; }
.tabla-buscar { flex: 1; max-width: 340px; border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 10px; padding: 9px 12px; font-size: 13px; outline: none; }
.tabla-buscar:focus { border-color: #2563eb; background: white; }
.btn-nuevo { background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); color: white; border: none; border-radius: 10px; padding: 9px 16px; font-size: 13px; font-weight: 700; cursor: pointer; }

.tabla-estado { padding: 36px; text-align: center; color: #64748b; font-size: 13px; }
.tabla-error { color: #dc2626; }

.tabla-scroll { overflow-x: auto; }
.tabla { width: 100%; border-collapse: collapse; font-size: 13px; }
.tabla th { text-align: left; font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: 700; padding: 10px 12px; border-bottom: 1px solid #e2e8f0; white-space: nowrap; }
.tabla td { padding: 11px 12px; border-bottom: 1px solid #f1f5f9; color: #0f172a; }
.tabla tbody tr:hover { background: #f8fafc; }
.col-acciones { text-align: right; white-space: nowrap; width: 1%; }

.badge { display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; text-transform: capitalize; }
.badge-ok { background: #dcfce7; color: #15803d; }
.badge-off { background: #f1f5f9; color: #64748b; }
.badge-warn { background: #fef3c7; color: #b45309; }
.badge-bad { background: #fee2e2; color: #b91c1c; }

.icono-btn { background: #f8fafc; border: 1px solid #e2e8f0; color: #475569; width: 32px; height: 32px; border-radius: 8px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; margin-left: 6px; }
.icono-btn:hover { background: #eff6ff; color: #2563eb; }
.icono-btn.peligro:hover { background: #fef2f2; color: #dc2626; }
.fila-inactiva td { color: #94a3b8; }
.txt-btn { border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 8px; padding: 6px 10px; margin-left: 6px; font-size: 12px; font-weight: 700; cursor: pointer; }
.txt-btn.ok { color: #15803d; } .txt-btn.ok:hover { background: #dcfce7; }
.txt-btn.bad { color: #b91c1c; } .txt-btn.bad:hover { background: #fee2e2; }
</style>